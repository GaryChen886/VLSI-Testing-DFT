#include <iostream> 
#include <vector>
#include <string>
#include <algorithm>
#include "circuit.h"
#include "GetLongOpt.h"
#include <stack>
#include <random>
#include <chrono>

using namespace std;

extern GetLongOpt option;

void CIRCUIT::FanoutList()
{
    unsigned i = 0, j;
    GATE* gptr;
    for (;i < No_Gate();i++) {
        gptr = Gate(i);
        for (j = 0;j < gptr->No_Fanin();j++) {
            gptr->Fanin(j)->AddOutput_list(gptr);
        }
    }
}

void CIRCUIT::Levelize()
{
    list<GATE*> Queue;
    GATE* gptr;
    GATE* out;
    unsigned j = 0;
    for (unsigned i = 0;i < No_PI();i++) {
        gptr = PIGate(i);
        gptr->SetLevel(0);
        for (j = 0;j < gptr->No_Fanout();j++) {
            out = gptr->Fanout(j);
            if (out->GetFunction() != G_PPI) {
                out->IncCount();
                if (out->GetCount() == out->No_Fanin()) {
                    out->SetLevel(1);
                    Queue.push_back(out);
                }
            }
        }
    }
    for (unsigned i = 0;i < No_PPI();i++) {
        gptr = PPIGate(i);
        gptr->SetLevel(0);
        for (j = 0;j < gptr->No_Fanout();j++) {
            out = gptr->Fanout(j);
            if (out->GetFunction() != G_PPI) {
                out->IncCount();
                if (out->GetCount() ==
                        out->No_Fanin()) {
                    out->SetLevel(1);
                    Queue.push_back(out);
                }
            }
        }
    }
    int l1, l2;
    while (!Queue.empty()) {
        gptr = Queue.front();
        Queue.pop_front();
        l2 = gptr->GetLevel();
        for (j = 0;j < gptr->No_Fanout();j++) {
            out = gptr->Fanout(j);
            if (out->GetFunction() != G_PPI) {
                l1 = out->GetLevel();
                if (l1 <= l2)
                    out->SetLevel(l2 + 1);
                out->IncCount();
                if (out->GetCount() ==
                        out->No_Fanin()) {
                    Queue.push_back(out);
                }
            }
        }
    }
    for (unsigned i = 0;i < No_Gate();i++) {
        Gate(i)->ResetCount();
    }
}

void CIRCUIT::Check_Levelization()
{

    GATE* gptr;
    GATE* in;
    unsigned i, j;
    for (i = 0;i < No_Gate();i++) {
        gptr = Gate(i);
        if (gptr->GetFunction() == G_PI) {
            if (gptr->GetLevel() != 0) {
                cout << "Wrong Level for PI : " <<
                gptr->GetName() << endl;
                exit( -1);
            }
        }
        else if (gptr->GetFunction() == G_PPI) {
            if (gptr->GetLevel() != 0) {
                cout << "Wrong Level for PPI : " <<
                gptr->GetName() << endl;
                exit( -1);
            }
        }
        else {
            for (j = 0;j < gptr->No_Fanin();j++) {
                in = gptr->Fanin(j);
                if (in->GetLevel() >= gptr->GetLevel()) {
                    cout << "Wrong Level for: " <<
                    gptr->GetName() << '\t' <<
                    gptr->GetID() << '\t' <<
                    gptr->GetLevel() <<
                    " with fanin " <<
                    in->GetName() << '\t' <<
                    in->GetID() << '\t' <<
                    in->GetLevel() <<
                    endl;
                }
            }
        }
    }
}

void CIRCUIT::SetMaxLevel()
{
    for (unsigned i = 0;i < No_Gate();i++) {
        if (Gate(i)->GetLevel() > MaxLevel) {
            MaxLevel = Gate(i)->GetLevel();
        }
    }
}

//Setup the Gate ID and Inversion
//Setup the list of PI PPI PO PPO
void CIRCUIT::SetupIO_ID()
{
    unsigned i = 0;
    GATE* gptr;
    vector<GATE*>::iterator Circuit_ite = Netlist.begin();
    for (; Circuit_ite != Netlist.end();Circuit_ite++, i++) {
        gptr = (*Circuit_ite);
        gptr->SetID(i);
        switch (gptr->GetFunction()) {
            case G_PI: PIlist.push_back(gptr);
                break;
            case G_PO: POlist.push_back(gptr);
                break;
            case G_PPI: PPIlist.push_back(gptr);
                break;
            case G_PPO: PPOlist.push_back(gptr);
                break;
            case G_NOT: gptr->SetInversion();
                break;
            case G_NAND: gptr->SetInversion();
                break;
            case G_NOR: gptr->SetInversion();
                break;
            default:
                break;
        }
    }
}

void CIRCUIT::Assignment0() {
    // 0903
    int num_input = this->No_PI() ;
    printf("Number of inputs:%d\n", num_input);
    int num_output = this->No_PO() ;
    printf("Number of outputs:%d\n", num_output);

    // Set a vector used to store quantity of each type of logic gate
    const int gate_type = 11;
    vector<int> gate_count(gate_type, 0);
    int total_fanout = 0, branch_nets = 0, stem_nets = 0;
    //0905
    for_each(Netlist.begin(), Netlist.end(), [&](GATE* itr) {
        // Count the occurrences of each logic gate
        int function = itr->GetFunction();
        gate_count[function]++; 

        // Count the occurrences of each logic gate
        int fanout = itr->No_Fanout();
        total_fanout += fanout; 

        // Fanout > 1 -> Set as stem nets
        if (fanout > 1) {
            stem_nets++; 
            branch_nets += fanout; 
        }
    });
    int Q3 = gate_count[G_NOT] + gate_count[G_OR] + gate_count[G_NOR] + gate_count[G_AND] + gate_count[G_NAND];
    printf ("Total number of gates including inverter, or, nor, and, nand:%d\n", Q3);


    puts("Number of gates for each type:");
    vector<string> type {"G_PI", "G_PO", "G_PPI", "G_PPO", "G_NOT", "G_AND", "G_NAND", "G_OR", "G_NOR", "G_DFF", "G_BUF"};
    for (int i = 0; i < gate_type; i++)
        printf ("%-6s: %4d\n" , type[i].c_str(), gate_count[i]);
    printf ("Number of flip-flops:%d\n", gate_count[G_PPI]);

    // A gate connecting to different gates will be counted as different nets. => Fanout + stem nets
    int signal_nets = total_fanout + stem_nets;
    printf("Total number of signal nets:%d\n", signal_nets);
    printf("Number of branch nets:%d\n", branch_nets);
    printf("Number of stem nets:%d\n", stem_nets);

    double avg_fanout = static_cast<double>(total_fanout) / this->No_Gate();
    printf("Average number of fanouts of each gate (all types):%lf\n", avg_fanout);
}

// ref : https://github.com/cylinbao/VLSI-Testing/blob/master/podem/path.cc
// 0915
int CIRCUIT::TraceRoutes(const string& origin, const string& destination) {
    
    vector<bool> exploredGates(this->No_Gate(), false);
    vector<GATE*> currentPath;      // Stores the current path
    stack<GATE*> gateStack;         // Use for DFS to store gates
    GATE *tempGate = nullptr, *startGate = nullptr, *endGate = nullptr, *activeGate = nullptr;
    unsigned int pathCount = 0, prevLevel = 0;

    // Find the start gate
    for (unsigned int i = 0; i < this->No_PI(); i++) {
        tempGate = this->PIGate(i);
        if (tempGate->GetName() == origin) {
            startGate = tempGate;
            break;
        }
    }

    // Find the end gate
    for (unsigned int i = 0; i < this->No_PO(); i++) {
        tempGate = this->POGate(i);
        if (tempGate->GetName() == destination) {
            endGate = tempGate;
            break;
        }
    }

    if (!startGate || !endGate) {
        puts ("Error: Invalid input or output gate specified");
        return -1;
    }

    // Push the start gate onto the stack and begin search
    gateStack.push(startGate);

    // DFS  
    while (!gateStack.empty()) {
        activeGate = gateStack.top();
        gateStack.pop();

        // If activeGate is nullptr, skip
        if (!activeGate) {  
            continue;  
        }

        // Skip if the current gate level is deeper than the end gate
        if (activeGate->GetLevel() > endGate->GetLevel())
            continue;
        // Backtrack: remove gates in the path that are shallower than the current gate
        while (activeGate->GetLevel() < prevLevel && !currentPath.empty()) {
            prevLevel = currentPath.back()->GetLevel();
            currentPath.pop_back();
        }
        // Add the current gate to the path
        currentPath.push_back(activeGate);

        // End gate found
        if (activeGate->GetName() == endGate->GetName()) {
            // print the path and increment the count
            PrintPath(currentPath);
            ++pathCount;
        }
        else {
            // Push all fanout gates to stack
            // for (unsigned int i = 0; i < activeGate->No_Fanout(); i++) {
            //     gateStack.push(activeGate->Fanout(i));
            // }
            for (unsigned int i = 0; i < activeGate->No_Fanout(); i++) {
                GATE* fanoutGate = activeGate->Fanout(i);
                if (fanoutGate) {
                    gateStack.push(fanoutGate);
                }
            }

        }

        prevLevel = activeGate->GetLevel();
    }

    PrintSummary(origin, destination, pathCount);

    return pathCount;
}

void CIRCUIT::PrintPath(const vector<GATE*>& path) {
    for (const auto& gate : path) {
        cout << gate->GetName() << " ";
    }
    cout << endl;
}
void CIRCUIT::PrintSummary(const string& start, const string& end, int count) {
    cout << "The paths from " << start << " to " << end << ": " << count << endl;
}

//0917
void CIRCUIT::CreateRandomInputSequence(const std::string& output, int num, bool unkown) {
    std::ofstream outputFile(output);
    std::mt19937 rng(std::chrono::steady_clock::now().time_since_epoch().count());

    if (!outputFile.is_open()) {
        std::cerr << "Error: Unable to create output file. Check the provided path." << std::endl;
        throw std::runtime_error("File creation failed");
    }

    for (size_t i = 0; i < this->No_PI(); ++i) {
        outputFile << "Input " << this->PIGate(i)->GetName() << " ";
    }
    outputFile << "\n";

    std::uniform_int_distribution<> binaryDist(0, 1);
    std::uniform_int_distribution<> ternaryDist(0, 2);

    for (int i = 0; i < num; ++i) {
        std::string generatedSequence;
        for (size_t j = 0; j < No_PI() ; ++j) {
            if (!unkown) {
                generatedSequence += std::to_string(binaryDist(rng));
            } else {
                int value = ternaryDist(rng);
                generatedSequence += (value == 0) ? '0' : (value == 1) ? '1' : 'X';
            }
        }
        outputFile << generatedSequence << "\n";
    }

    std::cout << "Random input sequence generation complete. Output saved to: " << output << std::endl;
}

//0924
